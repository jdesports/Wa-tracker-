import json, re, sys, urllib.request, datetime, os

CHANNEL_URL = "https://whatsapp.com/channel/0029VbDZB4R0LKZ5NS0jvM0c"
DATA_FILE = "data.json"

def parse_count(s):
    s = s.replace(",", "").strip().lower()
    mult = 1
    if s.endswith("k"): mult, s = 1000, s[:-1]
    elif s.endswith("m"): mult, s = 1000000, s[:-1]
    return int(float(s) * mult)

req = urllib.request.Request(CHANNEL_URL, headers={"User-Agent": "Mozilla/5.0"})
html = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")
m = re.search(r"([\d.,]+\s?[KkMm]?)\s+followers", html)
if not m:
    sys.exit("Could not find follower count on the page")
count = parse_count(m.group(1))

data = {"channel": CHANNEL_URL, "name": "JD ESPORTS", "history": []}
if os.path.exists(DATA_FILE):
    data = json.load(open(DATA_FILE))
data["history"].append({"time": datetime.datetime.utcnow().isoformat(timespec="minutes") + "Z", "followers": count})
json.dump(data, open(DATA_FILE, "w"), indent=1)
print("Followers:", count)
